
import java.util.PriorityQueue;

public class MinHeapExample {

    public static void main(String[] args) {

        PriorityQueue<Integer> minHeap = new PriorityQueue<>(); 
            minHeap.add(10);
            minHeap.add(3);
            minHeap.add(87);
            minHeap.add(23);
            minHeap.add(12);
            minHeap.add(90);
            minHeap.add(99);
            minHeap.add(67);
            minHeap.add(1);
            minHeap.add(45);
           
       

        System.out.print("\nSorted order: ");

        while (!minHeap.isEmpty()) {
            System.out.print(minHeap.poll() + " ");
        }
    }
}
