package CollectionPrivate;

class Stack{
	int[] arr;
	int size;
	Stack(int size){
		arr = new int[size];
		size=0;
	}
	void push(int data) {
		if(size==arr.length) {
			System.out.println("stack overflow");
			return;
		}
		arr[size++]=data;
	}
	
	int pop() {
		if(size==0) {
			System.out.println("stack underflow");
			return -1000000000;
		}
		return arr[--size];
	}

	int peek() {
		if(size==0) {
			System.out.println("stack underflow");
			return -1000000000;
		}
		return arr[size-1];
	}
}

public class StackByArray {
public static void main(String[] args) {
	Stack s = new Stack(5);
	s.push(1);
	s.push(1);
	s.push(1);
	s.push(1);
	s.push(1);
	s.push(1);
	System.out.println(s.pop());
	System.out.println(s.pop());
	System.out.println(s.pop());
	System.out.println(s.pop());
	System.out.println(s.pop());
	System.out.println(s.pop());
	System.out.println(s.peek());
}
}
